
<?php
$pname=$_POST['pname'];
$pprice=$_POST['pprice'];


   

$target_dir = "sales/.";
echo json_encode($_FILES);
$target_file = $target_dir . basename($_FILES["image"]['name']);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$file_name=$_FILES['image']['name'];
$file_tmp=$_FILES['image']['tmp_name'];
  move_uploaded_file($file_tmp,"sales/".$file_name);
$location="sales/".$file_name;


  // Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}

$q1="INSERT INTO `sales` (`pname`,`pprice`,`pimage`) VALUES ('$pname','$pprice','$location')";

$conn=mysqli_connect('localhost','root','','form');
if($conn)
{
	echo "Connection Successfull";
}
else
{
	echo "Unsuccessfull";
}


$res=mysqli_query($conn,$q1);
if($res){
	echo '<script>alert("Submission Succcessfull");location.href="addsales.php"</script>';
}
else{
	echo "Unsuccessfull";
}




  #
  #
    

















?>s