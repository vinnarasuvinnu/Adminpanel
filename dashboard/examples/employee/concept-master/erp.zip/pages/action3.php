
<?php
$projname=$_POST['projname'];
$projdes=$_POST['projdes'];
$proj=$_POST['proj'];
$timeest=$_POST['timeest'];
$empneeded=$_POST['empneeded'];
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];

echo $projname;
echo $projdes;
echo $proj;
echo $timeest;
echo $empneeded;
echo $startdate;
echo $enddate;


   $q1="INSERT INTO `addreq` (`projname`, `projdes`, `proj`, `timeest`, `empneeded`, `startdate`,`enddate`) VALUES ('$projname', '$projdes', '$proj', '$timeest', '$empneeded', '$startdate', '$enddate');";

$conn=mysqli_connect('localhost','root','','form');
if($conn)
{
	echo "Connection Successfull";
}
else
{
	echo "Unsuccessfull";
}



$res=mysqli_query($conn,$q1);
if($res){
	echo '<script>alert("Submission Succcessfull");location.href="addreq.php";</script>';
}
else{
	echo "Unsuccessfull";
}






    

















?>