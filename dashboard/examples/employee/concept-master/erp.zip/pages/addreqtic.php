<?php
function reqtic($con){
	
				if(array_key_exists('email', $_POST)){
					$email=$_POST['email'];
					if(array_key_exists('problem', $_POST)){
					$problem=$_POST['problem'];


					$q1="INSERT INTO `reqtic` (`email`,`problem`) VALUES ('$email','$problem')";
					$res=mysqli_query($con,$q1);
					echo mysqli_error($con);
					if($res){

						success("ticket is added successfully");
					}
					else{
						fail("problem is missing");
					}
				}
				
				else{
					fail("email is missing");
				}
			}
			
		}

$con=mysqli_connect('localhost','root','','form');
reqtic($con);
function success($data){
echo json_encode(array('result'=>'success','description'=>$data));	
}

function fail($data){
	echo json_encode(array('result'=>'failure','description'=>$data));	
}
function out($data){
	echo json_encode(array('result'=>'success','description'=>$data));
}
?>