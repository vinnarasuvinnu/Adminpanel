<?php
function addticket($con){
	if(array_key_exists('pname',$_POST)){
		$pname=$_POST['pname'];
		if(array_key_exists('pid',$_POST )){
			$pid=$_POST['pid'];
			if(array_key_exists('dateofpurchase', $_POST)){
				$dateofpurchase=$_POST['dateofpurchase'];
				if(array_key_exists('uemail', $_POST)){
					$uemail=$_POST['uemail'];
					if(array_key_exists('reason', $_POST)){
					$reason=$_POST['reason'];


					$q1="INSERT INTO `tickets` (`pname`, `pid`, `dateofpurchase`, `uemail`,`reason`) VALUES ('$pname', '$pid', '$dateofpurchase', '$uemail','$reason')";
					$res=mysqli_query($con,$q1);
					echo mysqli_error($con);
					if($res){

						success("ticket is added successfully");
					}
					else{
						fail("something went wrong with adding ticket");
					}
				}
				else{
					fail("pname is missing");
				}

				}
				else{
					fail("uemail is missing");
				}
			}
			else{
				fail("reason is missing");

			}

		}
		else{
			fail("pid is missing");
		}
	}
	else{
		fail("dateofpurchase is missing");
	}

}

$con=mysqli_connect('localhost','root','','form');
addticket($con);
function success($data){
echo json_encode(array('result'=>'success','description'=>$data));	
}

function fail($data){
	echo json_encode(array('result'=>'failure','description'=>$data));	
}
function out($data){
	echo json_encode(array('result'=>'success','description'=>$data));
}



?>