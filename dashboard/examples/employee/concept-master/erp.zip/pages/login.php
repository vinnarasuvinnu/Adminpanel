
                         <?php
                         session_start();
$server_name="localhost";
$user="root";
$password="";
$name=$_POST['username'];
$pass=$_POST['password'];
$conn=mysqli_connect('localhost','root','','form');
$q1="select * from login where name='$name' and password='$pass'";

$res=mysqli_query($conn,$q1);
if(mysqli_num_rows($res)==1){
	$row=mysqli_fetch_array($res);
	$_SESSION['type']=$row['type'];
	header('Location:form-elements.php');


}
else{
	echo '<script>alert("sorry no data found");location.href="login.html"</script>';
}



?>